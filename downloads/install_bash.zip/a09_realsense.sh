# 0) Intel 옛 키/소스 제거
sudo rm -f /etc/apt/sources.list.d/librealsense.list /etc/apt/keyrings/librealsense.pgp

# 1) 사전 도구 + DKMS 빌드용 커널 헤더
sudo apt-get update
sudo apt-get install -y curl ca-certificates gnupg apt-transport-https \
  linux-headers-generic-hwe-24.04 "linux-headers-$(uname -r)"

# 2) realsenseai.com 키링 + apt 소스
sudo install -d -m 0755 /etc/apt/keyrings
curl -sSf https://librealsense.realsenseai.com/Debian/librealsenseai.asc \
  | gpg --dearmor | sudo tee /etc/apt/keyrings/librealsenseai.gpg >/dev/null
sudo chmod a+r /etc/apt/keyrings/librealsenseai.gpg
echo "deb [signed-by=/etc/apt/keyrings/librealsenseai.gpg] https://librealsense.realsenseai.com/Debian/apt-repo noble main" \
  | sudo tee /etc/apt/sources.list.d/librealsenseai.list >/dev/null
sudo apt-get update

# 3) SDK 패키지
sudo apt-get install -y \
  librealsense2-dkms librealsense2-utils librealsense2-dev librealsense2-dbg

# 4) ROS2 wrapper
sudo apt-get update
sudo apt-get install -y --only-upgrade \
  $(dpkg-query -W -f='${db:Status-Status} ${Package}\n' 'ros-jazzy-*' 2>/dev/null | awk '$1=="installed"{print $2}')
sudo apt-get install -y \
  ros-jazzy-realsense2-camera ros-jazzy-realsense2-description
  
# 5) RealSense udev 규칙 추가
# 적용 후 카메라 USB 를 뽑았다 다시 연결
sudo curl -fsSL https://raw.githubusercontent.com/IntelRealSense/librealsense/master/config/99-realsense-libusb.rules \
  -o /etc/udev/rules.d/99-realsense-libusb.rules
sudo udevadm control --reload-rules && sudo udevadm trigger


