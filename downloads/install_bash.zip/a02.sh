# 1) apt 활성화
sudo apt-get update
sudo apt-get install -y software-properties-common
sudo add-apt-repository -y universe
sudo add-apt-repository -y multiverse

# 2) 빌드 도구 + ubuntu-drivers
sudo apt-get update
sudo apt-get install -y build-essential gcc ubuntu-drivers-common dkms nvidia-modprobe

# 3) 드라이버 + HWE 커널모듈 메타 설치
#   ubuntu-drivers devices     # → recommended 버전 확인
sudo apt-get install -y \
  nvidia-driver-595 linux-modules-nvidia-595-generic-hwe-24.04

# 4) 드라이버 버전 hold
sudo apt-mark hold nvidia-driver-595

# 검증: 부팅될 커널에 nvidia 커널 모듈이 실제로 있는지 확인
find /lib/modules -name 'nvidia.ko*'

